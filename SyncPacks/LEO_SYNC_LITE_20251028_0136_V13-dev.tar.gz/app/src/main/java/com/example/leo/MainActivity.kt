package com.example.leo

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.leo.ui.chat.ChatScreen
import com.example.leo.ui.settings.SettingsScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContent {
            val nav = rememberNavController()

            // Hoisted app theme preference (quick state; persist later via DataStore)
            var isDark by rememberSaveable { mutableStateOf(false) }

            MaterialTheme {
                NavHost(navController = nav, startDestination = "chat") {

                    composable("chat") {
                        ChatScreen(
                            onOpenSettings = { nav.navigate("settings") }
                        )
                    }

                    composable("settings") {
                        SettingsScreen(
                            isDark = isDark,
                            onToggleDark = { isDark = it }
                            // items + onTogglePythonSkill use their defaults
                        )
                    }
                }
            }
        }
    }
}
